#!/bin/bash
# Continue the rerun: financial and TPC-DS in parallel once the shared-validation benchmark has finished (SSB keeps running).
cd /root/agentdb-mid
export AGENTDB_URL=$(grep -h "^AGENTDB_URL=" .env | cut -d= -f2- | tr -d "\"'")
B=target/release/agentdb-mid
O=results/replay-rerun-20261101
until grep -q "^exit" results/shared-validation-full.log; do sleep 30; done
$B --pool 8 --out $O/financial replay-bench --spec exp/2026-10-11-generality/schemas/financial.json --libs exp/2026-10-11-generality/libs/financial-kept.json \
   --policies condition --oracles snapshot --sql-timeout-secs 1800 > $O/financial.log 2>&1 && echo "financial exit $?" >> $O/progress.txt &
$B --pool 8 --out $O/tpcds replay-bench --schema tpcds --libs results/tpcds-library.json --policies condition --oracles snapshot --sql-timeout-secs 1800 > $O/tpcds.log 2>&1; echo "tpcds exit $?" >> $O/progress.txt
wait
