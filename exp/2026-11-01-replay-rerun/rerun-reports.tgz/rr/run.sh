#!/bin/bash
# MAVRA (condition policy, snapshot oracle) replay with the current binary on the four archived libraries; no model calls.
cd /root/agentdb-mid
export AGENTDB_URL=$(grep -h "^AGENTDB_URL=" .env | cut -d= -f2- | tr -d "\"'")
B=target/release/agentdb-mid
O=results/replay-rerun-20261101
git rev-parse HEAD > $O/head.txt; sha256sum $B > $O/binary.sha256
for s in tpch ssb financial; do
  $B --pool 8 --out $O/$s replay-bench --spec exp/2026-10-11-generality/schemas/$s.json --libs exp/2026-10-11-generality/libs/$s-kept.json \
     --policies condition --oracles snapshot --sql-timeout-secs 1800 > $O/$s.log 2>&1; echo "$s exit $?" >> $O/progress.txt
done
$B --pool 8 --out $O/tpcds replay-bench --schema tpcds --libs results/tpcds-library.json --policies condition --oracles snapshot --sql-timeout-secs 1800 > $O/tpcds.log 2>&1
echo "tpcds exit $?" >> $O/progress.txt
echo done > $O/DONE
