#!/bin/bash
# Table VI: MAVRA (condition policy, snapshot oracle) replay with the final binary on the four archived libraries; no model calls.
cd /root/agentdb-mid
export AGENTDB_URL=$(grep -h "^AGENTDB_URL=" .env | cut -d= -f2- | tr -d "\"'")
B=target/release/agentdb-mid
O=results/replay-final2-20261101
mkdir -p $O
git rev-parse HEAD > $O/head.txt; sha256sum $B > $O/binary.sha256
run() {
  local s=$1; shift
  local t0=$(date +%s)
  $B --pool 6 --out $O/$s replay-bench "$@" --policies condition --oracles snapshot --sql-timeout-secs 1800 > $O/$s.log 2>&1
  echo "$s exit $? seconds $(( $(date +%s) - t0 ))" >> $O/progress.txt
}
for s in tpch ssb financial; do
  run $s --spec exp/2026-10-11-generality/schemas/$s.json --libs exp/2026-10-11-generality/libs/$s-kept.json &
done
run tpcds --schema tpcds --libs results/tpcds-library.json &
wait
echo done > $O/DONE
